package Pack;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;

@RestController
public class RESTcon {
    @RequestMapping("/reserveCHK")
    public HashMap<String, Object> reserveCHK(HttpServletRequest req, SearchBean searchBean) {
        String query = req.getParameter("id");
        searchBean.setInput(query);
        searchBean.setStart("0");
        FunDAO funDAO = new FunDAO();
        List<bookBean> res = null;
        res = funDAO.select("IdSearch", searchBean);

        int reserveCHK = res.get(0).getCnt();
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("reserveCHK", reserveCHK);
        return hashMap;
    }

    @RequestMapping("/rentCHK")
    public HashMap<String, Object> rentCHK(HttpServletRequest req, SearchBean searchBean) {
        String query = req.getParameter("id");
        searchBean.setInput(query);
        searchBean.setStart("0");
        FunDAO funDAO = new FunDAO();
        List<bookBean> reserveCHK = funDAO.select("beforeRentCHK", searchBean);
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("reserveCHK", reserveCHK);
        return hashMap;
    }

    @RequestMapping("/idCHK")
    public HashMap<String, Object> idCHK(HttpServletRequest req, SearchBean searchBean) {
        String query = req.getParameter("id");
        System.out.println(query);
        searchBean.setId(query);
        FunDAO funDAO = new FunDAO();
        List<bookBean> idCHK = funDAO.select("idCHK", searchBean);
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("idCHKresult", idCHK);
        return hashMap;
    }
}
